import googlemaps, itertools
from euclid_schedule.distancematrix import QMatrix
from utils.time import has_time_window_overlap

GOOGLE_MAPS_API_KEY = 'AIzaSyB5xFv9a9IdFjw4DWTRl4gkqHar-uBVqBA'
g = googlemaps.Client(key=GOOGLE_MAPS_API_KEY)

# Time Unit is in minutes for easier calculation

class BaseSchedule:
    def __init__(self, origin_lat, origin_lon, destination_lat, destination_lon, start_time, time_constraint, index, **kwargs):
        self.origin_lat = origin_lat
        self.origin_lon = origin_lon
        self.destination_lat = destination_lat
        self.destination_lon = destination_lon
        self.start_time = start_time
        self.time_constraint = time_constraint
        self.index = index
        if kwargs:
            self.type = "driver"
            for k, v in kwargs.items():
                setattr(self, k, v)
        else:
            self.type = "rider"

    @property
    def origin_latlon(self):
        '''
        :return: A tuple contains the lat/lon of the origin
        '''
        return (self.origin_lat, self.origin_lon)

    @property
    def dest_latlon(self):
        '''
        :return: A tuple contains the lat/lon of the destination
        '''
        return (self.destination_lat, self.destination_lon)

    def get_latlons(self):
        '''
        Obtains the latitude and longitude of the origin and destination
        :return: two lon/lat pairs for origin and destination
        '''
        return self.origin_latlon, self.dest_latlon

def get_distance_matrix(schedules : [BaseSchedule]):
    locations = [ l for s in schedules for l in s.get_latlons()]
    distance_matrix = QMatrix(GOOGLE_MAPS_API_KEY)
    distance_matrix.query(locations)
    return distance_matrix

def match(driver : BaseSchedule, riders : [BaseSchedule]):

    if not riders:
        return
    distance_matrix = get_distance_matrix([driver] + riders)
    combination_max_len = min(driver.car_capacity, 5, len(riders))

    for combination_len in range(combination_max_len, 0, -1):
        result = make_match(driver, riders, combination_len, distance_matrix)
        if result:
            return result

def make_match(driver : BaseSchedule,
               riders : [BaseSchedule],
               combination_target : int,
               distance_matrix : QMatrix):

    driver_departure_time_window = (
        driver.start_time, driver.start_time + driver.time_constraint
    )
    driver_arrival_time_window = (
        driver.start_time + distance_matrix.get_duration(origin=driver.origin_latlon, destination=driver.dest_latlon) / 60,
        driver.start_time + distance_matrix.get_duration(origin=driver.origin_latlon, destination=driver.dest_latlon) / 60 + driver.extra_time + driver.time_constraint
    )

    rider_departure_time_windows_dict = \
        {rider : (rider.start_time, rider.start_time + rider.time_constraint)
         for rider in riders}
    rider_arrival_time_windows_dict = \
        {rider:
             (
                 rider.start_time + distance_matrix.get_duration(origin=rider.origin_latlon, destination=rider.dest_latlon) / 60,
                 rider.start_time + distance_matrix.get_duration(origin=rider.origin_latlon, destination=rider.dest_latlon) / 60 + rider.time_constraint
             )
         for rider in riders}

    def is_driver_compatible(route : []):
        complete_route_time_in_minute = sum(
            [
                distance_matrix.get_duration(route[i], route[i+1]) / 60 for i in range(len(route) - 1)
            ]
        )
        return has_time_window_overlap(
            driver_departure_time_window[0] + complete_route_time_in_minute,
            driver_departure_time_window[1] + complete_route_time_in_minute,
            driver_arrival_time_window[0],
            driver_arrival_time_window[1]
        )

    def is_rider_compatible(route : [], route_riders : [BaseSchedule]):
        for rider in route_riders:

            # the estimated time spent in between driver's departure time and the rider is picked up
            rider_pickup_time_spent_in_minute = sum(
                [
                    distance_matrix.get_duration(route[i], route[i + 1]) / 60
                    for i in range(route.index(rider.origin_latlon))
                ]
            )

            rider_dropoff_time_spent_in_minute = rider_pickup_time_spent_in_minute + sum(
                [
                    distance_matrix.get_duration(route[i], route[i + 1]) / 60
                    for i in range(route.index(rider.origin_latlon),
                                   route.index(rider.dest_latlon))
                ]
            )

            rider_departure_time_window = rider_departure_time_windows_dict[rider]
            rider_arrival_time_window = rider_arrival_time_windows_dict[rider]
            actual_rider_departure_time_window = (
                driver_departure_time_window[0] + rider_pickup_time_spent_in_minute,
                driver_departure_time_window[1] + rider_pickup_time_spent_in_minute
            )
            actual_rider_arrival_time_window = (
                driver_departure_time_window[0] + rider_dropoff_time_spent_in_minute,
                driver_departure_time_window[1] + rider_dropoff_time_spent_in_minute
            )

            can_pickup_rider_on_time = has_time_window_overlap(
                actual_rider_departure_time_window[0],
                actual_rider_departure_time_window[1],
                rider_departure_time_window[0],
                rider_departure_time_window[1]
            )

            can_dropoff_rider_on_time = has_time_window_overlap(
                actual_rider_arrival_time_window[0],
                actual_rider_arrival_time_window[1],
                rider_arrival_time_window[0],
                rider_arrival_time_window[1]
            )

            # TODO : DEBUG
            print("rider_departure_time_window :", rider_departure_time_window)
            print("rider_arrival_time_window :", rider_arrival_time_window)
            print("actual_rider_departure_time_window: ", actual_rider_departure_time_window)
            print("actual_rider_arrival_time_window: ", actual_rider_arrival_time_window)
            print("can_pickup_rider_on_time", can_pickup_rider_on_time)
            print("can_dropoff_rider_on_time", can_dropoff_rider_on_time)
            print()
            # TODO : END DEBUG

            if not can_pickup_rider_on_time or not can_dropoff_rider_on_time:
                return False
        return True

    # check the combinations
    if len(riders) == combination_target:
        all_rider_combinations = [tuple(riders)]
    elif len(riders) > combination_target:
        all_rider_combinations = itertools.combinations(riders, combination_target)
    else:
        raise ValueError("The number of riders is smaller than the combination target")

    for rider_combination in all_rider_combinations:
        rider_locations = [p for rider in rider_combination for p in rider.get_latlons()]
        routes = itertools.permutations(rider_locations)

        for route in routes:
            is_route_valid = True
            for rider in rider_combination:
                if route.index(rider.origin_latlon) > route.index(rider.dest_latlon):
                    is_route_valid = False
                    break
            if not is_route_valid:
                continue
            # construct on the complete route
            route = list(route)
            route.insert(0, driver.origin_latlon)
            route.append(driver.dest_latlon)
            driver_is_compatible = is_driver_compatible(route)
            rider_is_compatible = is_rider_compatible(route, rider_combination)

            if not driver_is_compatible or not rider_is_compatible:
                continue
            else:
                return rider_combination
    return None