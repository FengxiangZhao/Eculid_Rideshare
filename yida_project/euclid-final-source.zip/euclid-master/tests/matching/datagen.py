import os
import csv

def write_csv(dir, fn, rows):
    '''
    Write all rows to a CSV
    If dir is None, then it is set to ./tests/matching/data/
    '''
    if not dir:
        BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        dir = os.path.join(BASE_DIR, 'matching','data')
    with open(os.path.join(dir, fn), 'wt') as csvfile:
        wrtr = csv.writer(csvfile, delimiter=',', quoting=csv.QUOTE_NONNUMERIC)
        wrtr.writerows(rows)

def read_csv(dir, fn):
    '''
    Read all csv as a list of dicts, where each dict are the column names
    '''
    if not dir:
        BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        dir = os.path.join(BASE_DIR, 'matching','data')
    with open(os.path.join(dir, fn), 'r') as csvfile:
        rdr = list(csv.reader(csvfile, delimiter=',',quoting=csv.QUOTE_NONNUMERIC ))
        colnames = rdr[0]
        result = []
        for row in rdr[1:]:
            # zip ignores excessive elements in the longer list
            # which in our case, driver will have elements that rider does not have
            if not row:
                continue
            print(row)
            d = dict(zip(colnames, row))
            result.append(d)
    return result
def data_gen():
    colnames = [
        "origin_lat",
        "origin_lon",
        "destination_lat",
        "destination_lon",
        "start_time",
        "time_constraint",
        "index",
        "extra_time",
        "car_capacity"
    ]
    data = [
        [41.507350,-81.607160, 41.479985,-81.801197, 30, 30, 0, 25, 2],
        [41.508719,-81.598534, 41.500711,-81.690096, 20, 40, 1],
        [41.4271638, -81.6091472, 41.475236,-81.799091, 15, 60, 2],
        [41.507350, -81.607160, 41.479985, -81.801197, 30, 30, 0, 25, 2]
    ]
    return [colnames] + data

def init_schedule_from_data(data : [{}]):
    from tests.matching.matching import BaseSchedule
    drivers = []
    riders = []
    for dat in data:
        s = BaseSchedule(**dat)
        if s.type == 'driver':
            drivers.append(s)
        else:
            riders.append(s)
    return drivers, riders
