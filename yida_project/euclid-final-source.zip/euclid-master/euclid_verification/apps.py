from django.apps import AppConfig


class EuclidVerificationConfig(AppConfig):
    name = 'euclid_verification'
