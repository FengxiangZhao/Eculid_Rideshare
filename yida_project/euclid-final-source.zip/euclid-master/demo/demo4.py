from euclid_schedule.models import DriverSchedule, RiderSchedule

d = DriverSchedule.objects.get(id = 2)
r1 = RiderSchedule.objects.get(id = 1)
r2 = RiderSchedule.objects.get(id = 2)

r1.matching_driver = d
r1.save()
r2.matching_driver = d
r2.save()

RiderSchedule.objects.filter(matching_driver=d).update(matching_driver=None)