from tests.matching.matching import match, BaseSchedule

#from tests.matching.matching import *
d = BaseSchedule(41.507350,-81.607160, 41.479985,-81.801197, 20, 100, 0, extra_time=2000, car_capacity=4)

r1 = BaseSchedule(41.4271638, -81.5891472, 41.547155, -81.73115, 25, 90, 1)

r2 = BaseSchedule(41.4471638, -81.9091472, 41.547255, -81.65515, 35, 100, 2)

r3 = BaseSchedule(41.4571638, -81.1091472, 41.587105, -81.63115, 22, 12000, 3)

r4 = BaseSchedule(41.4371638, -81.1291472, 41.287185, -81.64315, 15, 150, 4)

r5 = BaseSchedule(41.4171638, -81.2991472, 41.547155, -81.66415, 10, 95, 5)

result = match(d, [r1,r2,r3,r4,r5])

print("Driver is going to pick up:")
for r in result:
    print(r.index)