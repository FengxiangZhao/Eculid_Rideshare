![](C:\Workspace\mappa\single-passenger-route-time.png)



```
m = PA.EST - DA.EST
n = PA.LAT - DA.LAT
p = PA.EST - DA.LAT
q = PA.LAT - DA.EST

r : DA's wait time
k : DA's extra time

r + k + w = DA.EST - DA.LAT
```

- `m < 0` : Passenger's EST is $|m|$ minutes earlier than driver's EST
  - `q < 0` : Passenger's LAT is $|q|$ minutes earlier than driver's EST  
    - PA and DA no match
  - `q >= 0`: Passenger's time window overlaps with that of driver's
    - PA and DA match if
      - `DA.EST + x + y <= PA.LAT`
        - Or `x + y <= q`
        - This ensures that driver could send the passenger home within passenger's time limit
      - `DA.EST + x + y + z <= DA.LAT`
        - Or `x + y + z <= r + k + w`
        - This ensures that driver could arrive at the destination within his own time limit
- `m > 0` : Passenger's EST is $m$ minutes later than driver's EST
  - `q < 0`: Passenger's LAT is $|q|$ minutes earlier than driver's EST
    - Invalid time
  - `q >= 0`:
    - `p <= 0` 





**This would not work.**

#### Prior Knowledge

- PA and DA could match iff their time window overlaps

#### Procedures

- Matching algorithms runs less frequently to perform match.
- After matching algorithm finishes, store the resulting pools into the django cache. If two pools in the cache have the same driverschedule, remove one of them based on metrics of the pools. (Requires override of object comparison functions)
- Scanning algorithms runs on the cache. If the driver, 