from django.apps import AppConfig


class EuclidAuthorizationConfig(AppConfig):
    name = 'euclid_authorization'
