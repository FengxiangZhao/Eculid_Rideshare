# django
from django.conf import settings
# rest framwork
from rest_framework import serializers
# local
from .models import DriverSchedule, RiderSchedule
from euclid_authorization.serializers import ClientSerializer
from euclid_authorization.models import Client


class BaseScheduleSerializer(serializers.ModelSerializer):
    owner = ClientSerializer(required=False, read_only=True)

    class Meta:
        exclude = ("is_cancelled", "owner")
        depth = 3

class DriverScheduleSerializer(serializers.ModelSerializer):

    def to_representation(self, instance):
        data = super(serializers.ModelSerializer, self).to_representation(instance)
        data["matched_rider"] = ClientSerializer([ rider.owner for rider in RiderSchedule.objects.filter(matching_driver=instance)], many=True).data
        return data

    class Meta(BaseScheduleSerializer.Meta):
        model = DriverSchedule
        read_only_fields = ("matched_rider",)

class RiderScheduleSerializer(serializers.ModelSerializer):
    matched_driver = ClientSerializer(read_only=True)

    def to_representation(self, instance):
        data = super(serializers.ModelSerializer, self).to_representation(instance)
        if instance.matching_driver:
            data["matched_driver"] = ClientSerializer(instance.matching_driver.owner).data
        else:
            data["matched_driver"] = None
        return data

    class Meta(BaseScheduleSerializer.Meta):
        model = RiderSchedule
        exclude = ("is_cancelled", "matching_driver", "owner")
        read_only_fields = ("owner",)




