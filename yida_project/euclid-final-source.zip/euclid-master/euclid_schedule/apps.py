from django.apps import AppConfig


class EuclidScheduleConfig(AppConfig):
    name = 'euclid_schedule'
