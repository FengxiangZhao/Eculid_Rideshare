chmod u+x ./server-setup/celery/celery_beat.sh
chmod u+x ./server-setup/celery/celery_worker.sh
chmod u+x ./server-setup/gunicorn/gunicorn_start.sh