#!/bin/bash
DJANGODIR=/websites/euclid/project/             # Django project directory
cd $DJANGODIR
source ./venv/bin/activate

exec ./venv/bin/celery worker -A mappa -l info 